<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="industrial-sprite-sheet-DeadEnd-LMZ" tilewidth="32" tileheight="32" spacing="2" margin="1" tilecount="40" columns="5">
 <image source="../../../Downloads/Industrial-Sprites-DeadEnd-LMZ/industrial-sprite-sheet-DeadEnd-LMZ.png" width="192" height="272"/>
</tileset>
