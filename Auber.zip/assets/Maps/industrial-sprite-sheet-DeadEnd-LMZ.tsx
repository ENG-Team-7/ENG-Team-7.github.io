<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="industrial-sprite-sheet-DeadEnd-LMZ" tilewidth="16" tileheight="16" tilecount="204" columns="12">
 <image source="industrial-sprite-sheet-DeadEnd-LMZ.png" width="192" height="272"/>
</tileset>
