<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="Background" tilewidth="1" tileheight="1" tilecount="408960" columns="852">
 <image source="background.jpg" width="852" height="480"/>
</tileset>
